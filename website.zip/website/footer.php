<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php">home</a>
         <a href="about.php">about</a>
         <a href="shop.php">shop</a>
         <a href="contact.php">contact</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> +91 99796 23724 </p>
         <p> <i class="fas fa-envelope"></i>essco27@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> SURENDRANAGR </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
      </div>

         <div>
      <p>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3670.677526463938!2d70.08583037056324!3d23.072281168390575!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3950b851a0875b29%3A0xf312964450980039!2sWard%203A%2C%20Adipur%2C%20Gandhidham%2C%20Gujarat%20370205!5e0!3m2!1sen!2sin!4v1742275426840!5m2!1sen!2sin" width="1500" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </p>
          </div>
          </div>
<!--
   <p class="credit"> &copy; copyright  @ <?php echo date('Y'); ?> by <span>mr. web designer</span> </p>
!-->
</section>